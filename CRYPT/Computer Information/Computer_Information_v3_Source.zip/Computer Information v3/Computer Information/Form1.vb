﻿Imports System.IO
Imports System.Net
Public Class Form1
    Dim NewPoint As New System.Drawing.Point()
    Dim X, Y As Integer
    ' ===================================================================
    ' ===================================================================
    ' All Version's Of "Computer Information" Have Been Coded
    ' By: JoSh iZ Fr3sH From HackForums.Net
    ' Anyone Who is Wishing To Re-Release This On Any WebSite
    ' Must Give Credit To The Original Source Owner (Me, JoSh iZ Fr3sH)
    ' ===================================================================
    ' ===================================================================
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = My.User.Name
        TextBox2.Text = My.Computer.Name
        TextBox3.Text = My.Computer.Info.AvailablePhysicalMemory
        TextBox4.Text = My.Computer.Info.AvailableVirtualMemory
        TextBox5.Text = My.Computer.Info.OSFullName
        TextBox6.Text = My.Computer.Info.OSPlatform
        TextBox7.Text = My.Computer.Info.OSVersion
        TextBox8.Text = My.Computer.Info.TotalPhysicalMemory
        TextBox9.Text = My.Computer.Info.TotalVirtualMemory
        TextBox10.Text = My.Computer.Clipboard.GetText
        TextBox11.Text = My.Computer.Clock.LocalTime
        TextBox12.Text = My.Computer.FileSystem.CurrentDirectory
        TextBox13.Text = My.Computer.Keyboard.CapsLock
        TextBox14.Text = My.Computer.Keyboard.NumLock
        TextBox15.Text = My.Computer.Keyboard.ScrollLock
        TextBox16.Text = My.Computer.Mouse.WheelExists
        '=============================================
        'Do NOT Edit This Part Please!
        TextBox17.Text = "JoSh iZ Fr3sH"
        'Do NOT Edit This Part Please!
        '=============================================
        ComboBox1.Items.AddRange(System.IO.Directory.GetLogicalDrives)
        ComboBox1.Text = ComboBox1.Items(0)
        TextBox20.Text = My.Computer.Info.InstalledUICulture.ToString
        Dim Husam As New System.Net.WebClient
        Dim ip As String
        ip = System.Text.Encoding.ASCII.GetString(( _
        Husam.DownloadData("Http://whatismyip.com/automation/n09230945.asp")))
        TextBox21.Text = ip
        Dim iphe As IPHostEntry = Dns.GetHostEntry("")
        TextBox22.Text = iphe.AddressList(0).ToString()
        Button3.Enabled = True
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        ' ===================================================================
        ' ===================================================================
        ' All Version's Of "Computer Information" Have Been Coded
        ' By: JoSh iZ Fr3sH From HackForums.Net
        ' Anyone Who is Wishing To Re-Release This On Any WebSite
        ' Must Give Credit To The Original Source Owner (Me, JoSh iZ Fr3sH)
        ' ===================================================================
        ' ===================================================================
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox8.Clear()
        TextBox9.Clear()
        TextBox10.Clear()
        TextBox11.Clear()
        TextBox12.Clear()
        TextBox13.Clear()
        TextBox14.Clear()
        TextBox15.Clear()
        TextBox16.Clear()
        TextBox17.Clear()
        TextBox20.Clear()
        ComboBox1.Text = ""
        ComboBox1.Items.Clear()
        TextBox21.Clear()
        TextBox22.Clear()
        Button3.Enabled = False
    End Sub
    ' ===================================================================
    ' ===================================================================
    ' All Version's Of "Computer Information" Have Been Coded
    ' By: JoSh iZ Fr3sH From HackForums.Net
    ' Anyone Who is Wishing To Re-Release This On Any WebSite
    ' Must Give Credit To The Original Source Owner (Me, JoSh iZ Fr3sH)
    ' ===================================================================
    ' ===================================================================
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim SaveFile As New SaveFileDialog
        SaveFile.FileName = "Comp Info"
        SaveFile.Filter = "Text Files (*.txt)|*.txt"
        SaveFile.Title = "Save"
        SaveFile.ShowDialog()
        Try
            Dim Write As New System.IO.StreamWriter(SaveFile.FileName)
            Write.Write(TextBox18.Text + ControlChars.NewLine + ControlChars.NewLine + ControlChars.NewLine + Label17.Text + ": " + TextBox1.Text + ControlChars.NewLine + ControlChars.NewLine + Label18.Text + ": " + TextBox2.Text + ControlChars.NewLine + ControlChars.NewLine + Label1.Text + ": " + TextBox3.Text + ControlChars.NewLine + ControlChars.NewLine + Label2.Text + ": " + TextBox4.Text + ControlChars.NewLine + ControlChars.NewLine + Label3.Text + ": " + TextBox5.Text + ControlChars.NewLine + ControlChars.NewLine + Label4.Text + ": " + TextBox6.Text + ControlChars.NewLine + ControlChars.NewLine + Label5.Text + ": " + TextBox7.Text + ControlChars.NewLine + ControlChars.NewLine + Label6.Text + ": " + TextBox8.Text + ControlChars.NewLine + ControlChars.NewLine + Label7.Text + ": " + TextBox9.Text + ControlChars.NewLine + ControlChars.NewLine + Label8.Text + ": " + TextBox10.Text + ControlChars.NewLine + ControlChars.NewLine + Label9.Text + ": " + TextBox11.Text + ControlChars.NewLine + ControlChars.NewLine + Label10.Text + ": " + TextBox12.Text + ControlChars.NewLine + ControlChars.NewLine + Label11.Text + ": " + TextBox13.Text + ControlChars.NewLine + ControlChars.NewLine + Label12.Text + ": " + TextBox14.Text + ControlChars.NewLine + ControlChars.NewLine + Label13.Text + ": " + TextBox15.Text + ControlChars.NewLine + ControlChars.NewLine + Label14.Text + ": " + TextBox16.Text + ControlChars.NewLine + ControlChars.NewLine + Label20.Text + ": " + ComboBox1.Text + ControlChars.NewLine + ControlChars.NewLine + Label21.Text + ": " + TextBox20.Text + ControlChars.NewLine + ControlChars.NewLine + Label22.Text + ": " + TextBox21.Text + ControlChars.NewLine + ControlChars.NewLine + Label23.Text + ": " + TextBox22.Text + ControlChars.NewLine + ControlChars.NewLine + Label15.Text + ": " + TextBox17.Text)
            Write.Close()
        Catch ex As Exception
        End Try
        MsgBox("Successfully Saved " & SaveFile.FileName, MsgBoxStyle.Information)
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        ' ===================================================================
        ' ===================================================================
        ' All Version's Of "Computer Information" Have Been Coded
        ' By: JoSh iZ Fr3sH From HackForums.Net
        ' Anyone Who is Wishing To Re-Release This On Any WebSite
        ' Must Give Credit To The Original Source Owner (Me, JoSh iZ Fr3sH)
        ' ===================================================================
        ' ===================================================================
        For FadeOut = 90 To 10 Step -10
            Me.Opacity = FadeOut / 100
            Me.Refresh()
            Threading.Thread.Sleep(50)
        Next
        End
    End Sub
    ' ===================================================================
    ' ===================================================================
    ' All Version's Of "Computer Information" Have Been Coded
    ' By: JoSh iZ Fr3sH From HackForums.Net
    ' Anyone Who is Wishing To Re-Release This On Any WebSite
    ' Must Give Credit To The Original Source Owner (Me, JoSh iZ Fr3sH)
    ' ===================================================================
    ' ===================================================================
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        For FadeIn = 0.0 To 1.1 Step 0.1
            Me.Opacity = FadeIn
            Me.Refresh()
            Threading.Thread.Sleep(100)
        Next
        NotifyIcon1.ShowBalloonTip(15)
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://www.hackforums.net")
    End Sub
End Class
' ===================================================================
' ===================================================================
' All Version's Of "Computer Information" Have Been Coded
' By: JoSh iZ Fr3sH From HackForums.Net
' Anyone Who is Wishing To Re-Release This On Any WebSite
' Must Give Credit To The Original Source Owner (Me, JoSh iZ Fr3sH)
' ===================================================================
' ===================================================================