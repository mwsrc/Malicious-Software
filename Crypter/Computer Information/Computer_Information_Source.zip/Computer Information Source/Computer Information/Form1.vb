﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = My.User.Name
        TextBox2.Text = My.Computer.Name
        TextBox3.Text = My.Computer.Info.AvailablePhysicalMemory
        TextBox4.Text = My.Computer.Info.AvailableVirtualMemory
        TextBox5.Text = My.Computer.Info.OSFullName
        TextBox6.Text = My.Computer.Info.OSPlatform
        TextBox7.Text = My.Computer.Info.OSVersion
        TextBox8.Text = My.Computer.Info.TotalPhysicalMemory
        TextBox9.Text = My.Computer.Info.TotalVirtualMemory
        TextBox10.Text = My.Computer.Clipboard.GetText
        TextBox11.Text = My.Computer.Clock.LocalTime
        TextBox12.Text = My.Computer.FileSystem.CurrentDirectory
        TextBox13.Text = My.Computer.Keyboard.CapsLock
        TextBox14.Text = My.Computer.Keyboard.NumLock
        TextBox15.Text = My.Computer.Keyboard.ScrollLock
        TextBox16.Text = My.Computer.Mouse.WheelExists
        '=============================================
        'Do NOT Edit This Part Please!
        TextBox17.Text = "JoSh iZ Fr3sH"
        TextBox18.Text = "HackForums.Net"
        'Do NOT Edit This Part Please!
        '=============================================
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox8.Clear()
        TextBox9.Clear()
        TextBox10.Clear()
        TextBox11.Clear()
        TextBox12.Clear()
        TextBox13.Clear()
        TextBox14.Clear()
        TextBox15.Clear()
        TextBox16.Clear()
        TextBox17.Clear()
        TextBox18.Clear()
    End Sub
End Class
