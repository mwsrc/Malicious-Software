﻿Imports System.IO
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = My.User.Name
        TextBox2.Text = My.Computer.Name
        TextBox3.Text = My.Computer.Info.AvailablePhysicalMemory
        TextBox4.Text = My.Computer.Info.AvailableVirtualMemory
        TextBox5.Text = My.Computer.Info.OSFullName
        TextBox6.Text = My.Computer.Info.OSPlatform
        TextBox7.Text = My.Computer.Info.OSVersion
        TextBox8.Text = My.Computer.Info.TotalPhysicalMemory
        TextBox9.Text = My.Computer.Info.TotalVirtualMemory
        TextBox10.Text = My.Computer.Clipboard.GetText
        TextBox11.Text = My.Computer.Clock.LocalTime
        TextBox12.Text = My.Computer.FileSystem.CurrentDirectory
        TextBox13.Text = My.Computer.Keyboard.CapsLock
        TextBox14.Text = My.Computer.Keyboard.NumLock
        TextBox15.Text = My.Computer.Keyboard.ScrollLock
        TextBox16.Text = My.Computer.Mouse.WheelExists
        '=============================================
        'Do NOT Edit This Part Please!
        TextBox17.Text = "JoSh iZ Fr3sH"
        TextBox18.Text = "HackForums.Net"
        'Do NOT Edit This Part Please!
        '=============================================
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox8.Clear()
        TextBox9.Clear()
        TextBox10.Clear()
        TextBox11.Clear()
        TextBox12.Clear()
        TextBox13.Clear()
        TextBox14.Clear()
        TextBox15.Clear()
        TextBox16.Clear()
        TextBox17.Clear()
        TextBox18.Clear()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim SaveFile As New SaveFileDialog
        SaveFile.FileName = "Comp Info"
        SaveFile.Filter = "Text Files (*.txt)|*.txt"
        SaveFile.Title = "Save"
        SaveFile.ShowDialog()
        Try
            Dim Write As New System.IO.StreamWriter(SaveFile.FileName)
            Write.Write(Label17.Text + ": " + TextBox1.Text + ControlChars.NewLine + ControlChars.NewLine + Label18.Text + ": " + TextBox2.Text + ControlChars.NewLine + ControlChars.NewLine + Label1.Text + ": " + TextBox3.Text + ControlChars.NewLine + ControlChars.NewLine + Label2.Text + ": " + TextBox4.Text + ControlChars.NewLine + ControlChars.NewLine + Label3.Text + ": " + TextBox5.Text + ControlChars.NewLine + ControlChars.NewLine + Label4.Text + ": " + TextBox6.Text + ControlChars.NewLine + ControlChars.NewLine + Label5.Text + ": " + TextBox7.Text + ControlChars.NewLine + ControlChars.NewLine + Label6.Text + ": " + TextBox8.Text + ControlChars.NewLine + ControlChars.NewLine + Label7.Text + ": " + TextBox9.Text + ControlChars.NewLine + ControlChars.NewLine + Label8.Text + ": " + TextBox10.Text + ControlChars.NewLine + ControlChars.NewLine + Label9.Text + ": " + TextBox11.Text + ControlChars.NewLine + ControlChars.NewLine + Label10.Text + ": " + TextBox12.Text + ControlChars.NewLine + ControlChars.NewLine + Label11.Text + ": " + TextBox13.Text + ControlChars.NewLine + ControlChars.NewLine + Label12.Text + ": " + TextBox14.Text + ControlChars.NewLine + ControlChars.NewLine + Label13.Text + ": " + TextBox15.Text + ControlChars.NewLine + ControlChars.NewLine + Label14.Text + ": " + TextBox16.Text + ControlChars.NewLine + ControlChars.NewLine + Label15.Text + ": " + TextBox17.Text + ControlChars.NewLine + ControlChars.NewLine + Label16.Text + ": " + TextBox18.Text)
            Write.Close()
        Catch ex As Exception
        End Try
        MsgBox("Successfully Saved " & SaveFile.FileName, MsgBoxStyle.Information)
    End Sub
End Class
