﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits DevComponents.DotNetBar.Office2007RibbonForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog
        Me.RibbonControl1 = New DevComponents.DotNetBar.RibbonControl
        Me.RibbonPanel1 = New DevComponents.DotNetBar.RibbonPanel
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.ButtonX2 = New DevComponents.DotNetBar.ButtonX
        Me.ButtonX1 = New DevComponents.DotNetBar.ButtonX
        Me.TextBoxX8 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.TextBoxX7 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.TextBoxX6 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.TextBoxX5 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.TextBoxX4 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.TextBoxX3 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.TextBoxX2 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.TextBoxX1 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.LabelX8 = New DevComponents.DotNetBar.LabelX
        Me.LabelX7 = New DevComponents.DotNetBar.LabelX
        Me.LabelX6 = New DevComponents.DotNetBar.LabelX
        Me.LabelX5 = New DevComponents.DotNetBar.LabelX
        Me.LabelX4 = New DevComponents.DotNetBar.LabelX
        Me.LabelX3 = New DevComponents.DotNetBar.LabelX
        Me.LabelX2 = New DevComponents.DotNetBar.LabelX
        Me.LabelX1 = New DevComponents.DotNetBar.LabelX
        Me.RibbonPanel3 = New DevComponents.DotNetBar.RibbonPanel
        Me.ComboBoxEx1 = New DevComponents.DotNetBar.Controls.ComboBoxEx
        Me.ButtonX6 = New DevComponents.DotNetBar.ButtonX
        Me.ButtonX5 = New DevComponents.DotNetBar.ButtonX
        Me.TextBoxX21 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.TextBoxX20 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.TextBoxX19 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.TextBoxX18 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.LabelX21 = New DevComponents.DotNetBar.LabelX
        Me.LabelX20 = New DevComponents.DotNetBar.LabelX
        Me.LabelX19 = New DevComponents.DotNetBar.LabelX
        Me.LabelX18 = New DevComponents.DotNetBar.LabelX
        Me.LabelX17 = New DevComponents.DotNetBar.LabelX
        Me.RibbonPanel2 = New DevComponents.DotNetBar.RibbonPanel
        Me.ButtonX4 = New DevComponents.DotNetBar.ButtonX
        Me.ButtonX3 = New DevComponents.DotNetBar.ButtonX
        Me.TextBoxX16 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.TextBoxX15 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.TextBoxX14 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.TextBoxX13 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.LabelX16 = New DevComponents.DotNetBar.LabelX
        Me.LabelX15 = New DevComponents.DotNetBar.LabelX
        Me.LabelX14 = New DevComponents.DotNetBar.LabelX
        Me.LabelX13 = New DevComponents.DotNetBar.LabelX
        Me.TextBoxX12 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.TextBoxX11 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.TextBoxX10 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.TextBoxX9 = New DevComponents.DotNetBar.Controls.TextBoxX
        Me.LabelX12 = New DevComponents.DotNetBar.LabelX
        Me.LabelX11 = New DevComponents.DotNetBar.LabelX
        Me.LabelX10 = New DevComponents.DotNetBar.LabelX
        Me.LabelX9 = New DevComponents.DotNetBar.LabelX
        Me.RibbonTabItem1 = New DevComponents.DotNetBar.RibbonTabItem
        Me.RibbonTabItem2 = New DevComponents.DotNetBar.RibbonTabItem
        Me.RibbonTabItem3 = New DevComponents.DotNetBar.RibbonTabItem
        Me.Office2007StartButton1 = New DevComponents.DotNetBar.Office2007StartButton
        Me.ItemContainer1 = New DevComponents.DotNetBar.ItemContainer
        Me.ItemContainer2 = New DevComponents.DotNetBar.ItemContainer
        Me.ItemContainer3 = New DevComponents.DotNetBar.ItemContainer
        Me.ButtonItem4 = New DevComponents.DotNetBar.ButtonItem
        Me.ItemContainer4 = New DevComponents.DotNetBar.ItemContainer
        Me.ButtonItem13 = New DevComponents.DotNetBar.ButtonItem
        Me.QatCustomizeItem1 = New DevComponents.DotNetBar.QatCustomizeItem
        Me.ColorPickerButton1 = New DevComponents.DotNetBar.ColorPickerButton
        Me.RibbonControl1.SuspendLayout()
        Me.RibbonPanel1.SuspendLayout()
        Me.RibbonPanel3.SuspendLayout()
        Me.RibbonPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'RibbonControl1
        '
        Me.RibbonControl1.CaptionVisible = True
        Me.RibbonControl1.Controls.Add(Me.RibbonPanel1)
        Me.RibbonControl1.Controls.Add(Me.RibbonPanel2)
        Me.RibbonControl1.Controls.Add(Me.RibbonPanel3)
        Me.RibbonControl1.Dock = System.Windows.Forms.DockStyle.Top
        Me.RibbonControl1.Items.AddRange(New DevComponents.DotNetBar.BaseItem() {Me.RibbonTabItem1, Me.RibbonTabItem2, Me.RibbonTabItem3})
        Me.RibbonControl1.KeyTipsFont = New System.Drawing.Font("Tahoma", 7.0!)
        Me.RibbonControl1.Location = New System.Drawing.Point(4, 1)
        Me.RibbonControl1.Name = "RibbonControl1"
        Me.RibbonControl1.Office2007ColorTable = DevComponents.DotNetBar.Rendering.eOffice2007ColorScheme.VistaGlass
        Me.RibbonControl1.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.RibbonControl1.QuickToolbarItems.AddRange(New DevComponents.DotNetBar.BaseItem() {Me.Office2007StartButton1, Me.QatCustomizeItem1})
        Me.RibbonControl1.Size = New System.Drawing.Size(540, 305)
        Me.RibbonControl1.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007
        Me.RibbonControl1.TabGroupHeight = 14
        Me.RibbonControl1.TabIndex = 0
        Me.RibbonControl1.Text = "RibbonControl1"
        '
        'RibbonPanel1
        '
        Me.RibbonPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007
        Me.RibbonPanel1.Controls.Add(Me.TextBox1)
        Me.RibbonPanel1.Controls.Add(Me.ButtonX2)
        Me.RibbonPanel1.Controls.Add(Me.ButtonX1)
        Me.RibbonPanel1.Controls.Add(Me.TextBoxX8)
        Me.RibbonPanel1.Controls.Add(Me.TextBoxX7)
        Me.RibbonPanel1.Controls.Add(Me.TextBoxX6)
        Me.RibbonPanel1.Controls.Add(Me.TextBoxX5)
        Me.RibbonPanel1.Controls.Add(Me.TextBoxX4)
        Me.RibbonPanel1.Controls.Add(Me.TextBoxX3)
        Me.RibbonPanel1.Controls.Add(Me.TextBoxX2)
        Me.RibbonPanel1.Controls.Add(Me.TextBoxX1)
        Me.RibbonPanel1.Controls.Add(Me.LabelX8)
        Me.RibbonPanel1.Controls.Add(Me.LabelX7)
        Me.RibbonPanel1.Controls.Add(Me.LabelX6)
        Me.RibbonPanel1.Controls.Add(Me.LabelX5)
        Me.RibbonPanel1.Controls.Add(Me.LabelX4)
        Me.RibbonPanel1.Controls.Add(Me.LabelX3)
        Me.RibbonPanel1.Controls.Add(Me.LabelX2)
        Me.RibbonPanel1.Controls.Add(Me.LabelX1)
        Me.RibbonPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RibbonPanel1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RibbonPanel1.Location = New System.Drawing.Point(0, 55)
        Me.RibbonPanel1.Name = "RibbonPanel1"
        Me.RibbonPanel1.Padding = New System.Windows.Forms.Padding(3, 0, 3, 3)
        Me.RibbonPanel1.Size = New System.Drawing.Size(540, 248)
        Me.RibbonPanel1.TabIndex = 1
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(3, 172)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(1, 1)
        Me.TextBox1.TabIndex = 57
        Me.TextBox1.Text = resources.GetString("TextBox1.Text")
        Me.TextBox1.Visible = False
        '
        'ButtonX2
        '
        Me.ButtonX2.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.ButtonX2.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground
        Me.ButtonX2.Location = New System.Drawing.Point(403, 127)
        Me.ButtonX2.Name = "ButtonX2"
        Me.ButtonX2.Size = New System.Drawing.Size(131, 111)
        Me.ButtonX2.TabIndex = 56
        Me.ButtonX2.Text = "Clear Info"
        '
        'ButtonX1
        '
        Me.ButtonX1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.ButtonX1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground
        Me.ButtonX1.Location = New System.Drawing.Point(403, 6)
        Me.ButtonX1.Name = "ButtonX1"
        Me.ButtonX1.Size = New System.Drawing.Size(131, 111)
        Me.ButtonX1.TabIndex = 55
        Me.ButtonX1.Text = "Get Info"
        '
        'TextBoxX8
        '
        '
        '
        '
        Me.TextBoxX8.Border.Class = "TextBoxBorder"
        Me.TextBoxX8.Location = New System.Drawing.Point(147, 216)
        Me.TextBoxX8.Name = "TextBoxX8"
        Me.TextBoxX8.Size = New System.Drawing.Size(244, 20)
        Me.TextBoxX8.TabIndex = 19
        '
        'TextBoxX7
        '
        '
        '
        '
        Me.TextBoxX7.Border.Class = "TextBoxBorder"
        Me.TextBoxX7.Location = New System.Drawing.Point(147, 186)
        Me.TextBoxX7.Name = "TextBoxX7"
        Me.TextBoxX7.Size = New System.Drawing.Size(244, 20)
        Me.TextBoxX7.TabIndex = 18
        '
        'TextBoxX6
        '
        '
        '
        '
        Me.TextBoxX6.Border.Class = "TextBoxBorder"
        Me.TextBoxX6.Location = New System.Drawing.Point(147, 156)
        Me.TextBoxX6.Name = "TextBoxX6"
        Me.TextBoxX6.Size = New System.Drawing.Size(244, 20)
        Me.TextBoxX6.TabIndex = 17
        '
        'TextBoxX5
        '
        '
        '
        '
        Me.TextBoxX5.Border.Class = "TextBoxBorder"
        Me.TextBoxX5.Location = New System.Drawing.Point(147, 126)
        Me.TextBoxX5.Name = "TextBoxX5"
        Me.TextBoxX5.Size = New System.Drawing.Size(244, 20)
        Me.TextBoxX5.TabIndex = 16
        '
        'TextBoxX4
        '
        '
        '
        '
        Me.TextBoxX4.Border.Class = "TextBoxBorder"
        Me.TextBoxX4.Location = New System.Drawing.Point(147, 96)
        Me.TextBoxX4.Name = "TextBoxX4"
        Me.TextBoxX4.Size = New System.Drawing.Size(244, 20)
        Me.TextBoxX4.TabIndex = 15
        '
        'TextBoxX3
        '
        '
        '
        '
        Me.TextBoxX3.Border.Class = "TextBoxBorder"
        Me.TextBoxX3.Location = New System.Drawing.Point(147, 66)
        Me.TextBoxX3.Name = "TextBoxX3"
        Me.TextBoxX3.Size = New System.Drawing.Size(244, 20)
        Me.TextBoxX3.TabIndex = 14
        '
        'TextBoxX2
        '
        '
        '
        '
        Me.TextBoxX2.Border.Class = "TextBoxBorder"
        Me.TextBoxX2.Location = New System.Drawing.Point(147, 36)
        Me.TextBoxX2.Name = "TextBoxX2"
        Me.TextBoxX2.Size = New System.Drawing.Size(244, 20)
        Me.TextBoxX2.TabIndex = 13
        '
        'TextBoxX1
        '
        '
        '
        '
        Me.TextBoxX1.Border.Class = "TextBoxBorder"
        Me.TextBoxX1.Location = New System.Drawing.Point(147, 6)
        Me.TextBoxX1.Name = "TextBoxX1"
        Me.TextBoxX1.Size = New System.Drawing.Size(244, 20)
        Me.TextBoxX1.TabIndex = 12
        '
        'LabelX8
        '
        Me.LabelX8.BackColor = System.Drawing.Color.Transparent
        Me.LabelX8.Location = New System.Drawing.Point(6, 216)
        Me.LabelX8.Name = "LabelX8"
        Me.LabelX8.Size = New System.Drawing.Size(132, 13)
        Me.LabelX8.TabIndex = 7
        Me.LabelX8.Text = "Total Physical Memory"
        '
        'LabelX7
        '
        Me.LabelX7.BackColor = System.Drawing.Color.Transparent
        Me.LabelX7.Location = New System.Drawing.Point(6, 186)
        Me.LabelX7.Name = "LabelX7"
        Me.LabelX7.Size = New System.Drawing.Size(132, 13)
        Me.LabelX7.TabIndex = 6
        Me.LabelX7.Text = "OS Version"
        '
        'LabelX6
        '
        Me.LabelX6.BackColor = System.Drawing.Color.Transparent
        Me.LabelX6.Location = New System.Drawing.Point(6, 156)
        Me.LabelX6.Name = "LabelX6"
        Me.LabelX6.Size = New System.Drawing.Size(132, 13)
        Me.LabelX6.TabIndex = 5
        Me.LabelX6.Text = "OS Platform"
        '
        'LabelX5
        '
        Me.LabelX5.BackColor = System.Drawing.Color.Transparent
        Me.LabelX5.Location = New System.Drawing.Point(6, 128)
        Me.LabelX5.Name = "LabelX5"
        Me.LabelX5.Size = New System.Drawing.Size(132, 13)
        Me.LabelX5.TabIndex = 4
        Me.LabelX5.Text = "OS Full Name"
        '
        'LabelX4
        '
        Me.LabelX4.BackColor = System.Drawing.Color.Transparent
        Me.LabelX4.Location = New System.Drawing.Point(3, 98)
        Me.LabelX4.Name = "LabelX4"
        Me.LabelX4.Size = New System.Drawing.Size(132, 13)
        Me.LabelX4.TabIndex = 3
        Me.LabelX4.Text = "Available Virtual Memory"
        '
        'LabelX3
        '
        Me.LabelX3.BackColor = System.Drawing.Color.Transparent
        Me.LabelX3.Location = New System.Drawing.Point(6, 68)
        Me.LabelX3.Name = "LabelX3"
        Me.LabelX3.Size = New System.Drawing.Size(132, 13)
        Me.LabelX3.TabIndex = 2
        Me.LabelX3.Text = "Available Physical Memory"
        '
        'LabelX2
        '
        Me.LabelX2.BackColor = System.Drawing.Color.Transparent
        Me.LabelX2.Location = New System.Drawing.Point(6, 37)
        Me.LabelX2.Name = "LabelX2"
        Me.LabelX2.Size = New System.Drawing.Size(132, 13)
        Me.LabelX2.TabIndex = 1
        Me.LabelX2.Text = "Computer Name"
        '
        'LabelX1
        '
        Me.LabelX1.BackColor = System.Drawing.Color.Transparent
        Me.LabelX1.Location = New System.Drawing.Point(6, 8)
        Me.LabelX1.Name = "LabelX1"
        Me.LabelX1.Size = New System.Drawing.Size(132, 13)
        Me.LabelX1.TabIndex = 0
        Me.LabelX1.Text = "UserName"
        '
        'RibbonPanel3
        '
        Me.RibbonPanel3.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007
        Me.RibbonPanel3.Controls.Add(Me.ComboBoxEx1)
        Me.RibbonPanel3.Controls.Add(Me.ButtonX6)
        Me.RibbonPanel3.Controls.Add(Me.ButtonX5)
        Me.RibbonPanel3.Controls.Add(Me.TextBoxX21)
        Me.RibbonPanel3.Controls.Add(Me.TextBoxX20)
        Me.RibbonPanel3.Controls.Add(Me.TextBoxX19)
        Me.RibbonPanel3.Controls.Add(Me.TextBoxX18)
        Me.RibbonPanel3.Controls.Add(Me.LabelX21)
        Me.RibbonPanel3.Controls.Add(Me.LabelX20)
        Me.RibbonPanel3.Controls.Add(Me.LabelX19)
        Me.RibbonPanel3.Controls.Add(Me.LabelX18)
        Me.RibbonPanel3.Controls.Add(Me.LabelX17)
        Me.RibbonPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RibbonPanel3.Location = New System.Drawing.Point(0, 55)
        Me.RibbonPanel3.Name = "RibbonPanel3"
        Me.RibbonPanel3.Padding = New System.Windows.Forms.Padding(3, 0, 3, 3)
        Me.RibbonPanel3.Size = New System.Drawing.Size(540, 248)
        Me.RibbonPanel3.TabIndex = 3
        Me.RibbonPanel3.Visible = False
        '
        'ComboBoxEx1
        '
        Me.ComboBoxEx1.DisplayMember = "Text"
        Me.ComboBoxEx1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBoxEx1.FormattingEnabled = True
        Me.ComboBoxEx1.ItemHeight = 14
        Me.ComboBoxEx1.Location = New System.Drawing.Point(153, 6)
        Me.ComboBoxEx1.Name = "ComboBoxEx1"
        Me.ComboBoxEx1.Size = New System.Drawing.Size(238, 20)
        Me.ComboBoxEx1.TabIndex = 62
        '
        'ButtonX6
        '
        Me.ButtonX6.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.ButtonX6.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground
        Me.ButtonX6.Location = New System.Drawing.Point(397, 6)
        Me.ButtonX6.Name = "ButtonX6"
        Me.ButtonX6.Size = New System.Drawing.Size(131, 230)
        Me.ButtonX6.TabIndex = 61
        Me.ButtonX6.Text = "Clear Info"
        '
        'ButtonX5
        '
        Me.ButtonX5.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.ButtonX5.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground
        Me.ButtonX5.Location = New System.Drawing.Point(12, 152)
        Me.ButtonX5.Name = "ButtonX5"
        Me.ButtonX5.Size = New System.Drawing.Size(379, 84)
        Me.ButtonX5.TabIndex = 60
        Me.ButtonX5.Text = "Get Info"
        '
        'TextBoxX21
        '
        '
        '
        '
        Me.TextBoxX21.Border.Class = "TextBoxBorder"
        Me.TextBoxX21.Location = New System.Drawing.Point(153, 126)
        Me.TextBoxX21.Name = "TextBoxX21"
        Me.TextBoxX21.Size = New System.Drawing.Size(238, 20)
        Me.TextBoxX21.TabIndex = 59
        '
        'TextBoxX20
        '
        '
        '
        '
        Me.TextBoxX20.Border.Class = "TextBoxBorder"
        Me.TextBoxX20.Location = New System.Drawing.Point(153, 96)
        Me.TextBoxX20.Name = "TextBoxX20"
        Me.TextBoxX20.Size = New System.Drawing.Size(238, 20)
        Me.TextBoxX20.TabIndex = 58
        '
        'TextBoxX19
        '
        '
        '
        '
        Me.TextBoxX19.Border.Class = "TextBoxBorder"
        Me.TextBoxX19.Location = New System.Drawing.Point(153, 65)
        Me.TextBoxX19.Name = "TextBoxX19"
        Me.TextBoxX19.Size = New System.Drawing.Size(238, 20)
        Me.TextBoxX19.TabIndex = 57
        '
        'TextBoxX18
        '
        '
        '
        '
        Me.TextBoxX18.Border.Class = "TextBoxBorder"
        Me.TextBoxX18.Location = New System.Drawing.Point(153, 36)
        Me.TextBoxX18.Name = "TextBoxX18"
        Me.TextBoxX18.Size = New System.Drawing.Size(238, 20)
        Me.TextBoxX18.TabIndex = 56
        '
        'LabelX21
        '
        Me.LabelX21.BackColor = System.Drawing.Color.Transparent
        Me.LabelX21.Location = New System.Drawing.Point(6, 127)
        Me.LabelX21.Name = "LabelX21"
        Me.LabelX21.Size = New System.Drawing.Size(132, 13)
        Me.LabelX21.TabIndex = 54
        Me.LabelX21.Text = "Program Creator"
        '
        'LabelX20
        '
        Me.LabelX20.BackColor = System.Drawing.Color.Transparent
        Me.LabelX20.Location = New System.Drawing.Point(6, 97)
        Me.LabelX20.Name = "LabelX20"
        Me.LabelX20.Size = New System.Drawing.Size(132, 13)
        Me.LabelX20.TabIndex = 53
        Me.LabelX20.Text = "Internal IP"
        '
        'LabelX19
        '
        Me.LabelX19.BackColor = System.Drawing.Color.Transparent
        Me.LabelX19.Location = New System.Drawing.Point(6, 68)
        Me.LabelX19.Name = "LabelX19"
        Me.LabelX19.Size = New System.Drawing.Size(132, 13)
        Me.LabelX19.TabIndex = 52
        Me.LabelX19.Text = "External IP"
        '
        'LabelX18
        '
        Me.LabelX18.BackColor = System.Drawing.Color.Transparent
        Me.LabelX18.Location = New System.Drawing.Point(6, 38)
        Me.LabelX18.Name = "LabelX18"
        Me.LabelX18.Size = New System.Drawing.Size(132, 13)
        Me.LabelX18.TabIndex = 51
        Me.LabelX18.Text = "Language"
        '
        'LabelX17
        '
        Me.LabelX17.BackColor = System.Drawing.Color.Transparent
        Me.LabelX17.Location = New System.Drawing.Point(6, 8)
        Me.LabelX17.Name = "LabelX17"
        Me.LabelX17.Size = New System.Drawing.Size(132, 13)
        Me.LabelX17.TabIndex = 50
        Me.LabelX17.Text = "Local Drives"
        '
        'RibbonPanel2
        '
        Me.RibbonPanel2.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007
        Me.RibbonPanel2.Controls.Add(Me.ButtonX4)
        Me.RibbonPanel2.Controls.Add(Me.ButtonX3)
        Me.RibbonPanel2.Controls.Add(Me.TextBoxX16)
        Me.RibbonPanel2.Controls.Add(Me.TextBoxX15)
        Me.RibbonPanel2.Controls.Add(Me.TextBoxX14)
        Me.RibbonPanel2.Controls.Add(Me.TextBoxX13)
        Me.RibbonPanel2.Controls.Add(Me.LabelX16)
        Me.RibbonPanel2.Controls.Add(Me.LabelX15)
        Me.RibbonPanel2.Controls.Add(Me.LabelX14)
        Me.RibbonPanel2.Controls.Add(Me.LabelX13)
        Me.RibbonPanel2.Controls.Add(Me.TextBoxX12)
        Me.RibbonPanel2.Controls.Add(Me.TextBoxX11)
        Me.RibbonPanel2.Controls.Add(Me.TextBoxX10)
        Me.RibbonPanel2.Controls.Add(Me.TextBoxX9)
        Me.RibbonPanel2.Controls.Add(Me.LabelX12)
        Me.RibbonPanel2.Controls.Add(Me.LabelX11)
        Me.RibbonPanel2.Controls.Add(Me.LabelX10)
        Me.RibbonPanel2.Controls.Add(Me.LabelX9)
        Me.RibbonPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RibbonPanel2.Location = New System.Drawing.Point(0, 55)
        Me.RibbonPanel2.Name = "RibbonPanel2"
        Me.RibbonPanel2.Padding = New System.Windows.Forms.Padding(3, 0, 3, 3)
        Me.RibbonPanel2.Size = New System.Drawing.Size(540, 248)
        Me.RibbonPanel2.TabIndex = 2
        Me.RibbonPanel2.Visible = False
        '
        'ButtonX4
        '
        Me.ButtonX4.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.ButtonX4.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground
        Me.ButtonX4.Location = New System.Drawing.Point(403, 127)
        Me.ButtonX4.Name = "ButtonX4"
        Me.ButtonX4.Size = New System.Drawing.Size(131, 111)
        Me.ButtonX4.TabIndex = 54
        Me.ButtonX4.Text = "Clear Info"
        '
        'ButtonX3
        '
        Me.ButtonX3.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.ButtonX3.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground
        Me.ButtonX3.Location = New System.Drawing.Point(403, 6)
        Me.ButtonX3.Name = "ButtonX3"
        Me.ButtonX3.Size = New System.Drawing.Size(131, 111)
        Me.ButtonX3.TabIndex = 53
        Me.ButtonX3.Text = "Get Info"
        '
        'TextBoxX16
        '
        '
        '
        '
        Me.TextBoxX16.Border.Class = "TextBoxBorder"
        Me.TextBoxX16.Location = New System.Drawing.Point(147, 216)
        Me.TextBoxX16.Name = "TextBoxX16"
        Me.TextBoxX16.Size = New System.Drawing.Size(244, 20)
        Me.TextBoxX16.TabIndex = 52
        '
        'TextBoxX15
        '
        '
        '
        '
        Me.TextBoxX15.Border.Class = "TextBoxBorder"
        Me.TextBoxX15.Location = New System.Drawing.Point(147, 186)
        Me.TextBoxX15.Name = "TextBoxX15"
        Me.TextBoxX15.Size = New System.Drawing.Size(244, 20)
        Me.TextBoxX15.TabIndex = 51
        '
        'TextBoxX14
        '
        '
        '
        '
        Me.TextBoxX14.Border.Class = "TextBoxBorder"
        Me.TextBoxX14.Location = New System.Drawing.Point(147, 156)
        Me.TextBoxX14.Name = "TextBoxX14"
        Me.TextBoxX14.Size = New System.Drawing.Size(244, 20)
        Me.TextBoxX14.TabIndex = 50
        '
        'TextBoxX13
        '
        '
        '
        '
        Me.TextBoxX13.Border.Class = "TextBoxBorder"
        Me.TextBoxX13.Location = New System.Drawing.Point(147, 126)
        Me.TextBoxX13.Name = "TextBoxX13"
        Me.TextBoxX13.Size = New System.Drawing.Size(244, 20)
        Me.TextBoxX13.TabIndex = 49
        '
        'LabelX16
        '
        Me.LabelX16.BackColor = System.Drawing.Color.Transparent
        Me.LabelX16.Location = New System.Drawing.Point(6, 217)
        Me.LabelX16.Name = "LabelX16"
        Me.LabelX16.Size = New System.Drawing.Size(132, 13)
        Me.LabelX16.TabIndex = 48
        Me.LabelX16.Text = "Mouse Wheel"
        '
        'LabelX15
        '
        Me.LabelX15.BackColor = System.Drawing.Color.Transparent
        Me.LabelX15.Location = New System.Drawing.Point(6, 187)
        Me.LabelX15.Name = "LabelX15"
        Me.LabelX15.Size = New System.Drawing.Size(132, 13)
        Me.LabelX15.TabIndex = 47
        Me.LabelX15.Text = "ScrollLock On or Off"
        '
        'LabelX14
        '
        Me.LabelX14.BackColor = System.Drawing.Color.Transparent
        Me.LabelX14.Location = New System.Drawing.Point(6, 156)
        Me.LabelX14.Name = "LabelX14"
        Me.LabelX14.Size = New System.Drawing.Size(132, 13)
        Me.LabelX14.TabIndex = 46
        Me.LabelX14.Text = "NumLock On or Off"
        '
        'LabelX13
        '
        Me.LabelX13.BackColor = System.Drawing.Color.Transparent
        Me.LabelX13.Location = New System.Drawing.Point(6, 128)
        Me.LabelX13.Name = "LabelX13"
        Me.LabelX13.Size = New System.Drawing.Size(132, 13)
        Me.LabelX13.TabIndex = 45
        Me.LabelX13.Text = "CapsLock On or Off"
        '
        'TextBoxX12
        '
        '
        '
        '
        Me.TextBoxX12.Border.Class = "TextBoxBorder"
        Me.TextBoxX12.Location = New System.Drawing.Point(147, 96)
        Me.TextBoxX12.Name = "TextBoxX12"
        Me.TextBoxX12.Size = New System.Drawing.Size(244, 20)
        Me.TextBoxX12.TabIndex = 44
        '
        'TextBoxX11
        '
        '
        '
        '
        Me.TextBoxX11.Border.Class = "TextBoxBorder"
        Me.TextBoxX11.Location = New System.Drawing.Point(147, 66)
        Me.TextBoxX11.Name = "TextBoxX11"
        Me.TextBoxX11.Size = New System.Drawing.Size(244, 20)
        Me.TextBoxX11.TabIndex = 43
        '
        'TextBoxX10
        '
        '
        '
        '
        Me.TextBoxX10.Border.Class = "TextBoxBorder"
        Me.TextBoxX10.Location = New System.Drawing.Point(147, 36)
        Me.TextBoxX10.Name = "TextBoxX10"
        Me.TextBoxX10.Size = New System.Drawing.Size(244, 20)
        Me.TextBoxX10.TabIndex = 42
        '
        'TextBoxX9
        '
        '
        '
        '
        Me.TextBoxX9.Border.Class = "TextBoxBorder"
        Me.TextBoxX9.Location = New System.Drawing.Point(147, 6)
        Me.TextBoxX9.Name = "TextBoxX9"
        Me.TextBoxX9.Size = New System.Drawing.Size(244, 20)
        Me.TextBoxX9.TabIndex = 41
        '
        'LabelX12
        '
        Me.LabelX12.BackColor = System.Drawing.Color.Transparent
        Me.LabelX12.Location = New System.Drawing.Point(6, 98)
        Me.LabelX12.Name = "LabelX12"
        Me.LabelX12.Size = New System.Drawing.Size(132, 13)
        Me.LabelX12.TabIndex = 40
        Me.LabelX12.Text = "Current File Directory"
        '
        'LabelX11
        '
        Me.LabelX11.BackColor = System.Drawing.Color.Transparent
        Me.LabelX11.Location = New System.Drawing.Point(6, 67)
        Me.LabelX11.Name = "LabelX11"
        Me.LabelX11.Size = New System.Drawing.Size(132, 13)
        Me.LabelX11.TabIndex = 39
        Me.LabelX11.Text = "Local Date and Time"
        '
        'LabelX10
        '
        Me.LabelX10.BackColor = System.Drawing.Color.Transparent
        Me.LabelX10.Location = New System.Drawing.Point(6, 38)
        Me.LabelX10.Name = "LabelX10"
        Me.LabelX10.Size = New System.Drawing.Size(132, 13)
        Me.LabelX10.TabIndex = 38
        Me.LabelX10.Text = "ClipBoard Text"
        '
        'LabelX9
        '
        Me.LabelX9.BackColor = System.Drawing.Color.Transparent
        Me.LabelX9.Location = New System.Drawing.Point(6, 8)
        Me.LabelX9.Name = "LabelX9"
        Me.LabelX9.Size = New System.Drawing.Size(132, 13)
        Me.LabelX9.TabIndex = 37
        Me.LabelX9.Text = "Total Virtual Memory"
        '
        'RibbonTabItem1
        '
        Me.RibbonTabItem1.Checked = True
        Me.RibbonTabItem1.Name = "RibbonTabItem1"
        Me.RibbonTabItem1.Panel = Me.RibbonPanel1
        Me.RibbonTabItem1.Text = "Computer Info"
        '
        'RibbonTabItem2
        '
        Me.RibbonTabItem2.Name = "RibbonTabItem2"
        Me.RibbonTabItem2.Panel = Me.RibbonPanel2
        Me.RibbonTabItem2.Text = "More Info"
        '
        'RibbonTabItem3
        '
        Me.RibbonTabItem3.Name = "RibbonTabItem3"
        Me.RibbonTabItem3.Panel = Me.RibbonPanel3
        Me.RibbonTabItem3.Text = "Even Move Info"
        '
        'Office2007StartButton1
        '
        Me.Office2007StartButton1.AutoExpandOnClick = True
        Me.Office2007StartButton1.CanCustomize = False
        Me.Office2007StartButton1.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.Image
        Me.Office2007StartButton1.Icon = CType(resources.GetObject("Office2007StartButton1.Icon"), System.Drawing.Icon)
        Me.Office2007StartButton1.ImagePaddingHorizontal = 2
        Me.Office2007StartButton1.ImagePaddingVertical = 2
        Me.Office2007StartButton1.Name = "Office2007StartButton1"
        Me.Office2007StartButton1.ShowSubItems = False
        Me.Office2007StartButton1.SubItems.AddRange(New DevComponents.DotNetBar.BaseItem() {Me.ItemContainer1})
        Me.Office2007StartButton1.Text = "&File"
        '
        'ItemContainer1
        '
        '
        '
        '
        Me.ItemContainer1.BackgroundStyle.Class = "RibbonFileMenuContainer"
        Me.ItemContainer1.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical
        Me.ItemContainer1.Name = "ItemContainer1"
        Me.ItemContainer1.SubItems.AddRange(New DevComponents.DotNetBar.BaseItem() {Me.ItemContainer2, Me.ItemContainer4})
        '
        'ItemContainer2
        '
        '
        '
        '
        Me.ItemContainer2.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer"
        Me.ItemContainer2.ItemSpacing = 0
        Me.ItemContainer2.Name = "ItemContainer2"
        Me.ItemContainer2.SubItems.AddRange(New DevComponents.DotNetBar.BaseItem() {Me.ItemContainer3})
        '
        'ItemContainer3
        '
        '
        '
        '
        Me.ItemContainer3.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer"
        Me.ItemContainer3.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical
        Me.ItemContainer3.MinimumSize = New System.Drawing.Size(120, 0)
        Me.ItemContainer3.Name = "ItemContainer3"
        Me.ItemContainer3.SubItems.AddRange(New DevComponents.DotNetBar.BaseItem() {Me.ButtonItem4})
        '
        'ButtonItem4
        '
        Me.ButtonItem4.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText
        Me.ButtonItem4.Image = CType(resources.GetObject("ButtonItem4.Image"), System.Drawing.Image)
        Me.ButtonItem4.Name = "ButtonItem4"
        Me.ButtonItem4.SubItemsExpandWidth = 24
        Me.ButtonItem4.Text = "&Save..."
        '
        'ItemContainer4
        '
        '
        '
        '
        Me.ItemContainer4.BackgroundStyle.Class = "RibbonFileMenuBottomContainer"
        Me.ItemContainer4.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right
        Me.ItemContainer4.Name = "ItemContainer4"
        Me.ItemContainer4.SubItems.AddRange(New DevComponents.DotNetBar.BaseItem() {Me.ButtonItem13})
        '
        'ButtonItem13
        '
        Me.ButtonItem13.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText
        Me.ButtonItem13.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground
        Me.ButtonItem13.Image = CType(resources.GetObject("ButtonItem13.Image"), System.Drawing.Image)
        Me.ButtonItem13.Name = "ButtonItem13"
        Me.ButtonItem13.SubItemsExpandWidth = 24
        Me.ButtonItem13.Text = "E&xit"
        '
        'QatCustomizeItem1
        '
        Me.QatCustomizeItem1.Enabled = False
        Me.QatCustomizeItem1.Name = "QatCustomizeItem1"
        Me.QatCustomizeItem1.Visible = False
        '
        'ColorPickerButton1
        '
        Me.ColorPickerButton1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.ColorPickerButton1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground
        Me.ColorPickerButton1.Image = CType(resources.GetObject("ColorPickerButton1.Image"), System.Drawing.Image)
        Me.ColorPickerButton1.Location = New System.Drawing.Point(58, 4)
        Me.ColorPickerButton1.Name = "ColorPickerButton1"
        Me.ColorPickerButton1.SelectedColorImageRectangle = New System.Drawing.Rectangle(2, 2, 12, 12)
        Me.ColorPickerButton1.Size = New System.Drawing.Size(37, 23)
        Me.ColorPickerButton1.TabIndex = 1
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(548, 306)
        Me.Controls.Add(Me.ColorPickerButton1)
        Me.Controls.Add(Me.RibbonControl1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Computer Information v4"
        Me.RibbonControl1.ResumeLayout(False)
        Me.RibbonControl1.PerformLayout()
        Me.RibbonPanel1.ResumeLayout(False)
        Me.RibbonPanel1.PerformLayout()
        Me.RibbonPanel3.ResumeLayout(False)
        Me.RibbonPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents RibbonControl1 As DevComponents.DotNetBar.RibbonControl
    Friend WithEvents RibbonPanel1 As DevComponents.DotNetBar.RibbonPanel
    Friend WithEvents RibbonTabItem1 As DevComponents.DotNetBar.RibbonTabItem
    Friend WithEvents Office2007StartButton1 As DevComponents.DotNetBar.Office2007StartButton
    Friend WithEvents ItemContainer1 As DevComponents.DotNetBar.ItemContainer
    Friend WithEvents ItemContainer2 As DevComponents.DotNetBar.ItemContainer
    Friend WithEvents ItemContainer3 As DevComponents.DotNetBar.ItemContainer
    Friend WithEvents ButtonItem4 As DevComponents.DotNetBar.ButtonItem
    Friend WithEvents ItemContainer4 As DevComponents.DotNetBar.ItemContainer
    Friend WithEvents ButtonItem13 As DevComponents.DotNetBar.ButtonItem
    Friend WithEvents QatCustomizeItem1 As DevComponents.DotNetBar.QatCustomizeItem
    Friend WithEvents ColorPickerButton1 As DevComponents.DotNetBar.ColorPickerButton
    Friend WithEvents LabelX8 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX7 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX6 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX5 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX4 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX3 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX2 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX1 As DevComponents.DotNetBar.LabelX
    Friend WithEvents TextBoxX8 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents TextBoxX7 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents TextBoxX6 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents TextBoxX5 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents TextBoxX4 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents TextBoxX3 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents TextBoxX2 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents TextBoxX1 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents RibbonPanel2 As DevComponents.DotNetBar.RibbonPanel
    Friend WithEvents RibbonTabItem2 As DevComponents.DotNetBar.RibbonTabItem
    Friend WithEvents TextBoxX16 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents TextBoxX15 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents TextBoxX14 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents TextBoxX13 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents LabelX16 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX15 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX14 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX13 As DevComponents.DotNetBar.LabelX
    Friend WithEvents TextBoxX12 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents TextBoxX11 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents TextBoxX10 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents TextBoxX9 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents LabelX12 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX11 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX10 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX9 As DevComponents.DotNetBar.LabelX
    Friend WithEvents RibbonPanel3 As DevComponents.DotNetBar.RibbonPanel
    Friend WithEvents TextBoxX21 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents TextBoxX20 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents TextBoxX19 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents TextBoxX18 As DevComponents.DotNetBar.Controls.TextBoxX
    Friend WithEvents LabelX21 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX20 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX19 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX18 As DevComponents.DotNetBar.LabelX
    Friend WithEvents LabelX17 As DevComponents.DotNetBar.LabelX
    Friend WithEvents RibbonTabItem3 As DevComponents.DotNetBar.RibbonTabItem
    Friend WithEvents ButtonX5 As DevComponents.DotNetBar.ButtonX
    Friend WithEvents ButtonX4 As DevComponents.DotNetBar.ButtonX
    Friend WithEvents ButtonX3 As DevComponents.DotNetBar.ButtonX
    Friend WithEvents ButtonX2 As DevComponents.DotNetBar.ButtonX
    Friend WithEvents ButtonX1 As DevComponents.DotNetBar.ButtonX
    Friend WithEvents ButtonX6 As DevComponents.DotNetBar.ButtonX
    Friend WithEvents ComboBoxEx1 As DevComponents.DotNetBar.Controls.ComboBoxEx
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox

End Class
