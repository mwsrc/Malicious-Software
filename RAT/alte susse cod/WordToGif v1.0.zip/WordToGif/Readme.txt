Hello everyone,


I am not responsible if u r not reading this and proceeding with the code and not getting the exact results.

There are situations when you need to converted the selected text/any area in a word processor to a bitmap format. I had this situation when working with a project, so i thought of making this app. (The GIF Class was written by Arkadiy Olovyannikov (ark@fesma.ru)

This software is FREEWARE. You may use it as you see fit for your own projects but you may not re-sell the original or the source code.

No warranty express or implied, is given as to the use of this program. Use at your own risk.


This is the VB code to convert the Selected MSWord Text/Images into GIF format.I am attaching the code along with this. I hope this would help u.

Before continuing further, let me explain the procedure in less detail.

First of all, click on the open menu, to get the open dialog box, where u can select any file u wish to convert to GIF format. Select the Area u want to convert and then copy it to the clipboard (by pressing CTRL+C ). After that close the window and then get to the main screen. Select Save opaque or save transparent options from the Convert menu item. Now, enter the filename u want your gif should be along with the full path (this is to get a small bug fixed, which occur while using save as dialog box). Now your job is over. just check for your file.

Small Enhancement you can do in this : I have no time to code the exact image size of the selected text. As of now , you can resize the form to a size you wanted your image to be and continue with the above procedure (this should be done before selecting the open menu item). I guess you can do that.

NOTE: The GIF format is copyrighted to CompuServe INC. If you are using the image to yourself, then its well and good, if you plan to sell your images, you have to inform CompuServe INC befor doing So.

I have also included the complete GIF manual by CompuServe, the way to convert other formats into the GIF images are clearly explained in that.


Bye,
Happy Programming!!!!!

S I D H U