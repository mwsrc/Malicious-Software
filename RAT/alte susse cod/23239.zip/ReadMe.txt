Hi I am Dinesh Chachan. A student of BIT. I am in my 5th sem. I wrote this program just to get access to the registry through VB.This program is especially made for Windows 2000

There are some bugs in the program. If you find one please mail be the details of the bug and if possible with the solution. 

My mail id is dineshchachan@rediffmail.com