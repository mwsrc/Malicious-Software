#define Drive1 1000
#define Dir1 10001
#define File1 10002

Microsoft HTML Help Compiler 4.74.8702

Compiling c:\Documents and Settings\Aftab\Desktop\HelpProject\HelpHello.chm


Compile time: 0 minutes, 1 second
4	Topics
0	Local links
0	Internet links
0	Graphics


Created c:\Documents and Settings\Aftab\Desktop\HelpProject\HelpHello.chm, 10,679 bytes
Compression increased file by 9,576 bytes.
Microsoft HTML Help Compiler 4.74.8702

Compiling c:\Documents and Settings\Aftab\Desktop\HelpProject\HelpHello.chm


Compile time: 0 minutes, 1 second
4	Topics
0	Local links
0	Internet links
0	Graphics


Created c:\Documents and Settings\Aftab\Desktop\HelpProject\HelpHello.chm, 10,679 bytes
Compression increased file by 9,576 bytes.
